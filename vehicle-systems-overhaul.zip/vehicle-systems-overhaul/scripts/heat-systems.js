const MODULE_ID = "vehicle-systems-overhaul";

function hasHeat(actor) {
  return actor?.getFlag(MODULE_ID, "heat.enabled") === true;
}

function getHeat(actor) {
  return Math.max(0, Number(actor?.getFlag(MODULE_ID, "heat.value")) || 0);
}

function getHeatMax(actor) {
  return Math.max(0, Number(actor?.getFlag(MODULE_ID, "heat.max")) || 0);
}

class HeatSystemConfig extends dnd5e.applications.actor.BaseConfigSheetV2 {  static DEFAULT_OPTIONS = {
    classes: ["heat-systems", "vehicle-systems-overhaul-heat-config"],
    position: { width: 420 }
  };
  static PARTS = {
    config: {
      template: `modules/${MODULE_ID}/templates/heat-systems-config.hbs`
    }
  }
  
  async _preparePartContext(partId, context, options) {
    context = await super._preparePartContext(partId, context, options);
    context.heat = { 
      enabled: hasHeat(this.document), 
      value: getHeat(this.document), 
      max: getHeatMax(this.document) 
    };
    return context;
  }
  
  async _processSubmitData(event, form, formData) {
    const fields = new FormData(form);
    const prefix = `flags.${MODULE_ID}.heat.`;
    const numeric = (field, fallback) => {
      const input = fields.get(prefix + field);
      const value = input === null ? fallback : Number(input);
      return Number.isFinite(value) ? Math.max(0, Math.trunc(value)) : fallback;
    };
    const max = numeric("max", getHeatMax(this.document));
    const value = Math.min(max, numeric("value", getHeat(this.document)));
    const enabled = fields.has(prefix + "enabled");

    await this.document.update({
      [prefix + "enabled"]: enabled,
      [prefix + "max"]: max,
      [prefix + "value"]: value
    });
  }
}